<?php
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = '';
$redirectToFormCadastroPedidos = false;

$idCliente = isset($_POST["tf_idcliente"]) ? addslashes(trim($_POST["tf_idcliente"])) : false;
$idProduto = isset($_POST["tf_idproduto"]) ? addslashes(trim($_POST["tf_idproduto"])) : false;
$quantidade = isset($_POST["tf_quantidade"]) ? addslashes(trim($_POST["tf_quantidade"])) : false;
$data = isset($_POST["tf_data"]) ? addslashes(trim($_POST["tf_data"])) : false;

$pedido = executar_SQL("SELECT id, cliente_id, produto_id, quantidade, data FROM pedidos WHERE cliente_id = '$idCliente' AND produto_id = '$idProduto' AND data= '$data'");

if (!verifica_resultado($pedido)) {
  libera_consulta($pedido);
  $inserir = executar_SQL("INSERT INTO pedidos (cliente_id, produto_id, quantidade, data) VALUES ('$idCliente', '$idProduto', '$quantidade', '$data')");
  $msg = "Pedido Cadastrado com Sucesso!";
} else {
  $msg = "Pedido já Cadastrado.";
}

$redirectToFormCadastroPedidos = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Pedidos</title>
  <link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

  <!-- Modal -->
  <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true"
    data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel">Atenção
            <?php echo $_SESSION["snome"]; ?>
          </h5>
        </div>
        <div class="modal-body">
          <?php echo $msg; ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function () {
      $('#messageModal').modal({
        backdrop: 'static',
        keyboard: false
      });

      $('#closeBtn').click(function () {
        <?php
        if ($redirectToFormCadastroPedidos) {
          echo "window.location.href = '../html/form_cadastro_pedidos.html';";
        }
        ?>
      });
    });
  </script>

</body>

</html>