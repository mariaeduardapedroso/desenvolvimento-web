<?php
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = '';
$redirectToDashboard = false;

$id = isset($_GET["id"]) ? addslashes(trim($_GET["id"])) : false;
$produto = executar_SQL("SELECT * FROM Produtos WHERE id = '$id'");

if (!verifica_resultado($produto)) {
    $msg = "Produto não Cadastrado.";
    $redirectToDashboard = true;
} else {
    deletar("Produtos", "id = '$id'");
    $msg = "Produto Deletado com Sucesso!";
    $redirectToDashboard = true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remoção de Produtos</title>
    <link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <!-- Modal -->
    <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel"
        aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Atenção
                        <?php echo $_SESSION["snome"]; ?>
                    </h5>
                </div>
                <div class="modal-body">
                    <?php echo $msg; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#messageModal').modal({
                backdrop: 'static',
                keyboard: false
            });

            $('#closeBtn').click(function () {
                <?php
                if ($redirectToDashboard) {
                    echo "window.location.href = '../php/dashboard_produtos.php';";
                }
                ?>
            });
        });
    </script>

</body>

</html>

