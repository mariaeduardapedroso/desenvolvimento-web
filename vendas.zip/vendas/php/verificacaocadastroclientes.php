<?php
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = '';
$redirectToFormCadastroClientes = false;

$nome = isset($_POST["tf_nome"]) ? addslashes(trim($_POST["tf_nome"])) : false;
$email = isset($_POST["tf_email"]) ? addslashes(trim($_POST["tf_email"])) : false;
$endereco = isset($_POST["tf_endereco"]) ? addslashes(trim($_POST["tf_endereco"])) : false;

$cliente = executar_SQL("SELECT id, nome, email, endereco FROM clientes WHERE email = '$email' AND nome = '$nome'");

if (!verifica_resultado($cliente)) {
    libera_consulta($cliente);
    $inserir = executar_SQL("INSERT INTO Clientes(nome, email, endereco) VALUES ('$nome', '$email', '$endereco')");
    $msg = "Cliente Cadastrado com Sucesso!";
} else {
    $msg = "Cliente já Cadastrado.";
}

$redirectToFormCadastroClientes = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Clientes</title>
    <link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <!-- Modal -->
    <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel"
        aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Atenção
                        <?php echo $_SESSION["snome"]; ?>
                    </h5>
                </div>
                <div class="modal-body">
                    <?php echo $msg; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#messageModal').modal({
                backdrop: 'static',
                keyboard: false
            });

            $('#closeBtn').click(function () {
                <?php
                if ($redirectToFormCadastroClientes) {
                    echo "window.location.href = '../html/form_cadastro_clientes.html';";
                }
                ?>
            });
        });
    </script>

</body>

</html>