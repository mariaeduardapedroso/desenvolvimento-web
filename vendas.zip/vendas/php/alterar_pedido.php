<?php
// Inicia a sessão
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = 'Pedido Encontrado';
$redirectToDashboard = false;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Assumindo que sua função executar_SQL pode lidar com consultas preparadas, ajuste conforme necessário.
$row = executar_SQL("SELECT cliente_id, produto_id, quantidade, data FROM pedidos WHERE id = {$id}");
$pedido = $row->fetch_assoc();

// Verificação básica do resultado.
if (!$pedido) {
  $msg = "Erro ao recuperar o pedido.";
  $pedido = [
    "id" => $id,
    "cliente_id" => "",
    "produto_id" => "",
    "quantidade" => "",
    "data" => ""
  ];
  $redirectToDashboard = true;
} elseif ($_POST) {
  if (isset($_POST["pedido_id"]) && isset($_POST["tf_idcliente"]) && isset($_POST["tf_idproduto"]) && isset($_POST["tf_quantidade"]) && isset($_POST["tf_data"])) {
    $id = addslashes(trim($_POST["pedido_id"]));
    $idCliente = addslashes(trim($_POST["tf_idcliente"]));
    $idProduto = addslashes(trim($_POST["tf_idproduto"]));
    $quantidade = addslashes(trim($_POST["tf_quantidade"]));
    $data = addslashes(trim($_POST["tf_data"]));
    $dados = [
      "id" => $id,
      "cliente_id" => $idCliente,
      "produto_id" => $idProduto,
      "quantidade" => $quantidade,
      "data" => $data
    ];
    $alterado = alterar("pedidos", $dados, "id = {$id}");

    if (!$alterado) {
      $msg = "Não foi possivel alterar pedido!";
    } else {
      $msg = "Pedido Alterado com Sucesso!";
      $redirectToDashboard = true;
    }
  }
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Alteração de Pedidos - Sistema de Vendas</title>
  <link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link href="form-validation.css" rel="stylesheet">
</head>

<body class="bg-light">

  <div class="container">
    <main>
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="../img/logo.svg" alt="" width="150" height="140">
        <h2>Alterar Pedido</h2>
      </div>

      <div class="row g-5">


        <div class="col-md-7 col-lg-8">
          <form action="" method="post">
            <input type="hidden" name="pedido_id" value="<?php echo $id; ?>">
            <div class="row g-3">
              <div class="col-12">
                <label for="firstName" class="form-label">Id Cliente</label>
                <input name="tf_idcliente" type="number" class="form-control" id="idcliente" placeholder=""
                  value="<?php echo htmlspecialchars($pedido["cliente_id"]); ?>" required>
                <div class="invalid-feedback">
                  Por favor informe o id do Cliente.
                </div>
              </div>

              <div class="col-12">
                <label for="firstName" class="form-label">Id Produto</label>
                <input name="tf_idproduto" type="number" class="form-control" id="idproduto" placeholder=""
                  value="<?php echo htmlspecialchars($pedido["produto_id"]); ?>" required>
                <div class="invalid-feedback">
                  Por favor informe o id do Produto.
                </div>
              </div>

              <div class="col-12">
                <label for="username" class="form-label">Quantidade</label>
                <div class="input-group has-validation">
                  <input name="tf_quantidade" type="number" class="form-control" id="quantidade" placeholder="22"
                    value="<?php echo htmlspecialchars($pedido["quantidade"]); ?>" required>
                  <div class="invalid-feedback">
                    Por favor informe a quantidade do pedido.
                  </div>
                </div>
              </div>

              <div class="col-12 mb-4">
                <label for="email" class="form-label">Data</label>
                <input name="tf_data" type="date" class="form-control" id="date" placeholder="21-10-2023"
                  value="<?php echo htmlspecialchars($pedido["data"]); ?>" required>
                <div class="invalid-feedback">
                  Por favor informe a data.
                </div>
              </div>

              <button class="w-100 btn btn-primary btn-lg" type="submit">Cadastrar</button>

              <p><a href="dashboard_pedidos.php" class="link">Voltar</a></p>

          </form>
        </div>
      </div>
    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">&copy; Modificado por Maria Eduarda – 2023</p>

    </footer>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true"
    data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel">Atenção
            <?php echo $_SESSION["snome"]; ?>
          </h5>
        </div>
        <div class="modal-body">
          <?php echo $msg; ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
        </div>
      </div>
    </div>
  </div>


  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
    integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
    integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
    crossorigin="anonymous"></script>
  <script type="text/javascript">
    $(document).ready(function () {
      $('#messageModal').modal('show');

      $('#closeBtn').click(function () {
        <?php
        if ($redirectToDashboard) {
          echo "window.location.href = '../php/dashboard_pedidos.php';";
        }
        ?>
      });
    });
  </script>

</body>

</html>