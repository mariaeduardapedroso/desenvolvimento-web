<?php
// Inicia a sessão
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = 'Usuario Encontrado';
$redirectToDashboard = false;

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$row = executar_SQL("SELECT nome, email FROM usuarios WHERE id = {$id}");
$usuario = $row->fetch_assoc();

if (!$usuario) {
    $msg = "Erro ao recuperar o usuario.";
    $usuario = [
        "id" => $id,
        "nome" => "",
        "email" => ""
    ];
    $redirectToDashboard = true;
} elseif ($_POST) {
    if (isset($_POST["usuario_id"]) && isset($_POST["tf_nome"]) && isset($_POST["tf_email"])) {
        $id = addslashes(trim($_POST["usuario_id"]));
        $nome = addslashes(trim($_POST["tf_nome"]));
        $email = addslashes(trim($_POST["tf_email"]));
        $dados = [
            "id" => $id,
            "nome" => $nome,
            "email" => $email
        ];
        $alterado = alterar("usuarios", $dados, "id = {$id}");

        if (!$alterado) {
            $msg = "Não foi possivel alterar usuario!";
        } else {
            $msg = "Usuario Alterado com Sucesso!";
            $redirectToDashboard = true;
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alteração de usuarios - Sistema de Vendas</title>
    <link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="form-validation.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container">
        <main>
            <div class="py-5 text-center">
                <img class="d-block mx-auto mb-4" src="../img/logo.svg" alt="" width="150" height="140">
                <h2>Alterar usuario</h2>
            </div>

            <div class="row g-5">
                <div class="col-md-7 col-lg-8">
                    <form action="" method="post">
                        <input type="hidden" name="usuario_id" value="<?php echo $id; ?>">
                        <div class="row g-3">
                            <div class="col-12">
                                <label for="firstName" class="form-label">Nome</label>
                                <input name="tf_nome" type="text" class="form-control" id="firstName" placeholder=""
                                    value="<?php echo htmlspecialchars($usuario["nome"]); ?>" required>
                                <div class="invalid-feedback">
                                    Por favor, informe o nome do usuario.
                                </div>
                            </div>

                            <div class="col-12 mb-4">
                                <label for="email" class="form-label">E-mail </label>
                                <input name="tf_email" type="email" class="form-control" id="email"
                                    placeholder="you@example.com"
                                    value="<?php echo htmlspecialchars($usuario["email"]); ?>" required>
                                <div class="invalid-feedback">
                                    Por favor, informe o e-mail.
                                </div>
                            </div>

                            <button class="w-100 btn btn-primary btn-lg" type="submit">Alterar</button>
                            <p><a href="dashboard_usuarios.php" class="link">Voltar</a></p>
                    </form>
                </div>
            </div>
        </main>

        <footer class="my-5 pt-5 text-muted text-center text-small">
            <p class="mb-1">&copy; Modificado por Maria Eduarda – 2023</p>
        </footer>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel"
        aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Atenção
                        <?php echo $_SESSION["snome"]; ?>
                    </h5>
                </div>
                <div class="modal-body">
                    <?php echo $msg; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#messageModal').modal('show');

            $('#closeBtn').click(function () {
                <?php
                if ($redirectToDashboard) {
                    echo "window.location.href = '../php/dashboard_usuarios.php';";
                }
                ?>
            });
        });
    </script>
</body>

</html>