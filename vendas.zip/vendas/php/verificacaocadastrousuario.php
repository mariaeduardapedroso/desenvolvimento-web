<?php
require __DIR__ . '/../function/autentication.php';
include('../function/base.php');

$msg = '';
$redirectToFormCadastroUsuario = false;

$nomeusuario = isset($_POST["tf_nome"]) ? addslashes(trim($_POST["tf_nome"])) : false;
$email = isset($_POST["tf_nomeusuario"]) ? addslashes(trim($_POST["tf_nomeusuario"])) : false;
$senha = (strlen($_POST["tf_senha"]) > 0) ? md5(trim($_POST["tf_senha"])) : false;
$confirmasenha = (strlen($_POST["tf_confirmasenha"]) > 0) ? md5(trim($_POST["tf_confirmasenha"])) : false;

if ($senha != $confirmasenha) {
	$msg = "A senha digitada não é igual a confirmada!";
} else {
	$usuario = executar_SQL("SELECT id FROM Usuarios WHERE email = '$email'");
	if (!verifica_resultado($usuario)) {
		libera_consulta($usuario);
		$inserir = executar_SQL("INSERT INTO Usuarios(nome, email, senha) VALUES ('$nomeusuario', '$email', '$senha')");
		$msg = "Usuário Cadastrado com Sucesso!";
	} else {
		$msg = "Usuário já Cadastrado.";
	}
}

$redirectToFormCadastroUsuario = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cadastro de Usuários</title>
	<link rel="icon" href="../img/logo-minimalista.svg" type="image/svg+xml">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

	<!-- Modal -->
	<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel"
		aria-hidden="true" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modalLabel">Atenção
						<?php echo $_SESSION["snome"]; ?>
					</h5>
				</div>
				<div class="modal-body">
					<?php echo $msg; ?>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" id="closeBtn">Fechar</button>
				</div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function () {
			$('#messageModal').modal({
				backdrop: 'static',
				keyboard: false
			});

			$('#closeBtn').click(function () {
				<?php
				if ($redirectToFormCadastroUsuario) {
					echo "window.location.href = '../html/form_cadastro_usuario.html';";
				}
				?>
			});
		});
	</script>

</body>

</html>